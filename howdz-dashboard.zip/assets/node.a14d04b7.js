const e=e=>(n,s)=>((e,n=!0)=>{const s=[];return e.descendants(((e,t)=>{if(s.push({node:e,pos:t}),!n)return!1})),s})(n,s).filter((n=>e(n.node)));export{e as f};
